<div class="p-2">
    <div class="w-full overflow-hidden rounded-lg shadow-xs dark:bg-gray-800">
    <?php if(session()->has('message')): ?>
        <div id="alert" class="text-white px-6 py-4 border-0 rounded relative mb-4 bg-green-500">
            <span class="inline-block align-middle mr-8">
                <?php echo e(session('message')); ?>

            </span>
            <button class="absolute bg-transparent text-2xl font-semibold leading-none right-0 top-0 mt-4 mr-6 outline-none focus:outline-none" onclick="document.getElementById('alert').remove();">
                <span>×</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="retencion" x-data="{retencion: null}" x-init="">
        <div class="grid grid-cols-3 grid-flow-row gap-2 mb-2">
            <div class="bg-teal-400">
                <select
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300 form-select  block w-full"
                    x-ref="select_retencion"
                    x-on:change="if( $event.target.value == 4 ){retencion= 20}else{retencion=null}"
                >
                    <option value="1">Cheque inmediato</option>
                    <option value="2">Cheque diferido</option>
                    <option value="3">Transferencia</option>
                    <option value="4">Retención</option>
                </select>
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Número de Pago (Cheque, transferencia)"
                >
            </div>
            <div class="bg-teal-400">
                <select
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300 form-select  block w-full"
                >
                    <option>Banco emisor de pago</option>
                    <option value="1">Banco Bolivariano</option>
                    <option value="2">Banco del Pacífico</option>
                    <option value="3">Banco demo 3</option>
                    <option value="4">Banco demo 4</option>
                </select>
            </div>
            <div class="bg-teal-400">
                <select
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300 form-select  block w-full"
                >
                    <option>Banco receptor de pago</option>
                    <option value="1">Banco Bolivariano</option>
                    <option value="2">Banco del pacífico</option>
                    <option value="3">Banco demo 3</option>
                    <option value="4">Banco demo 4</option>
                </select>
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Fecha de documento del pago"
                >
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Fecha de vencimiento del pago"
                >
            </div>
            <div class="h-4 bg-teal-400">
                <select
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300 form-select  block w-full"
                >
                    <option>Moneda del documento</option>
                    <option value="1">USD</option>
                    <option value="2">Soles</option>
                </select>
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Importe del pago"
                >
            </div>



        </div>

        <div class="grid grid-cols-3 grid-flow-row gap-2" x-show="retencion">
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Territorio del saldo a favor"
                >
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Numero de comprobante de retecion"
                >
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Fecha de documento"
                >
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Base imponible"
                >
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Importe retencion"
                >
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Porcentaje de retencion"
                >
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Tipo de retencion"
                >
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Número de Autorización"
                >
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Fecha Inicio"
                >
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Fecha Fin"
                >
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Rango Inicio de Autorización"
                >
            </div>
            <div class="bg-teal-400">
                <input
                    type="text"
                    class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 w-full block rounded-none rounded-r-md sm:text-sm border-gray-300"
                    placeholder="Rango Fin de Autorización"
                >
            </div>
        </div>
    </div>


        <div class="w-full overflow-x-auto mt-4">
            <label class="block text-sm">
                <input
                    class="block w-full mt-1 text-sm dark:border-gray-600 dark:bg-gray-700 focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:text-gray-300 dark:focus:shadow-outline-gray form-input"
                    placeholder="Código Cliente"
                    wire:model="cod_cliente"
                    wire:keydown.enter="buscar_facturas"
                    >
                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-600 dark:text-red-400"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'ml-2 mt-2','wire:click' => 'buscar_facturas','wire:loading.attr' => 'disabled']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-2 mt-2','wire:click' => 'buscar_facturas','wire:loading.attr' => 'disabled']); ?>
                <?php echo e(__("Buscar")); ?>

             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'ml-2 mt-2','wire:loading.attr' => 'disabled']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-2 mt-2','wire:loading.attr' => 'disabled']); ?>
                <?php echo e(__("abonar")); ?>

             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        </div>



        <?php if( isset( $cliente->id ) ): ?>
        <div class="flex items-center p-4 bg-white rounded-lg shadow-xs dark:bg-gray-800">
            <div class="p-3 mr-4 text-orange-500 bg-orange-100 rounded-full dark:text-orange-100 dark:bg-orange-500">
                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"></path>
                </svg>
            </div>
            <div>
                <p class="mb-2 text-sm font-medium text-gray-600 dark:text-gray-400">
                    <?php echo e($cliente->name); ?>

                </p>
                <p class="text-lg font-semibold text-gray-700 dark:text-gray-200">
                    C: <?php echo e($cliente->code); ?>

                </p>
            </div>
        </div>


            <?php if( isset( $cliente->invoces ) ): ?>

            <div class="w-full mb-8 overflow-hidden rounded-lg shadow-xs">
                <div class="w-full overflow-x-auto">
                    <table class="w-full whitespace-no-wrap">
                    <thead>
                            <tr class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800">
                                <th class="px-4 py-3">Factura #</th>
                                <th class="px-4 py-3">Fecha</th>
                                <th class="px-4 py-3">V.T. Factura</th>
                                <th class="px-4 py-3">Saldo</th>
                                <th class="px-4 py-3">Saldo  Retención</th>
                                <th class="px-4 py-3">Abono</th>
                            </tr>
                    </thead>
                    <tbody class="bg-white divide-y dark:divide-gray-700 dark:bg-gray-800">
                            <?php $__currentLoopData = $cliente->invoces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700 dark:text-gray-400">
                                <td class="px-4 py-3"><?php echo e($factura->code); ?></td>
                                <td class="px-4 py-3"><?php echo e($factura->created_at); ?></td>
                                <td class="px-4 py-3">$ <?php echo e($factura->total); ?></td>
                                <!-- <td class="px-4 py-3">$ <?php echo e($total = $factura->pagos->sum('total')); ?></td> -->
                                <td class="">
                                    $ <?php echo e($factura->total - ($factura->total * 0.0175)); ?>

                                </td>
                                <td class="">
                                    $ <?php echo e($factura->total * 0.0175); ?>

                                </td>
                                <td class="">
                                    <input
                                        class="block w-full mt-1 text-sm dark:border-gray-600 dark:bg-gray-700 focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:text-gray-300 dark:focus:shadow-outline-gray form-input"
                                        placeholder="Saldo  Abono"
                                    >
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

        <?php endif; ?>


    </div>
    <div>
    </div>
</div>
<?php /**PATH D:\laragonf\www\nath\resources\views/livewire/pagar-cuentas.blade.php ENDPATH**/ ?>