<?php

namespace App\Http\Livewire;

use App\Models\Client;
use App\Models\Invoce;
use Livewire\Component;

class PagarCuentas extends Component
{
    public $cod_cliente;
    public Client $cliente;
    public $facturas = [];

    public $tipo_pago;

    public function render()
    {
        return view('livewire.pagar-cuentas');
    }


    public function buscar_facturas()
    {
        $this->cliente = Client::select("code","name","id")
                            ->where('code',$this->cod_cliente)
                            ->firstOr(function(){return new Client;});
    }
}
