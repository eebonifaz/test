<?php

namespace Database\Factories;

use App\Models\voucherType;
use Illuminate\Database\Eloquent\Factories\Factory;

class VoucherTypeFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = voucherType::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
