<?php

namespace Database\Factories;

use App\Models\Invoce;
use Illuminate\Database\Eloquent\Factories\Factory;

class InvoceFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Invoce::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
