<?php

namespace Database\Seeders;

use App\Models\Client;
use App\Models\Invoce;
use Illuminate\Database\Seeder;

class ClientSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $cliente1 = Client::create([
            "code" => "cliente1",
            "name" => "cliente1"
        ]);

        Invoce::create([
            "code" => "codigo2",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente1->id,
        ]);

        Invoce::create([
            "code" => "codigo3",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente1->id,
        ]);

        Invoce::create([
            "code" => "codigo4",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente1->id,
        ]);

        Invoce::create([
            "code" => "codigo5",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente1->id,
        ]);

        Invoce::create([
            "code" => "codigo6",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente1->id,
        ]);

        Invoce::create([
            "code" => "codigo7",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente1->id,
        ]);

        Invoce::create([
            "code" => "codigo8",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente1->id,
        ]);

        Invoce::create([
            "code" => "codigo9",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente1->id,
        ]);

        $cliente2 = Client::create([
            "code" => "cliente2",
            "name" => "cliente2"
        ]);

        Invoce::create([
            "code" => "codigo10",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente2->id,
        ]);
        $cliente3 = Client::create([
            "code" => "cliente3",
            "name" => "cliente3"
        ]);

        Invoce::create([
            "code" => "codigo11",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente3->id,
        ]);
        $cliente4 = Client::create([
            "code" => "cliente4",
            "name" => "cliente4"
        ]);


        Invoce::create([
            "code" => "codigo12",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente4->id,
        ]);

        $cliente5 = Client::create([
            "code" => "cliente5",
            "name" => "cliente5"
        ]);


        Invoce::create([
            "code" => "codigo13",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente5->id,
        ]);

        $cliente6 = Client::create([
            "code" => "cliente6",
            "name" => "cliente6"
        ]);


        Invoce::create([
            "code" => "codigo14",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente6->id,
        ]);

        $cliente7 = Client::create([
            "code" => "cliente7",
            "name" => "cliente7"
        ]);


        Invoce::create([
            "code" => "codigo15",
            "subtotal" => "10",
            "tax"   => "0.12",
            "descuento"  => "0.12",
            "total"     => "10",
            "client_id" => $cliente7->id,
        ]);
    }
}
