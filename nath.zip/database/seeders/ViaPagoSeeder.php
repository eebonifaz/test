<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ViaPagoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
