<?php return array (
  'pagar-cuentas' => 'App\\Http\\Livewire\\PagarCuentas',
  'users.permissions' => 'App\\Http\\Livewire\\Users\\Permissions',
);